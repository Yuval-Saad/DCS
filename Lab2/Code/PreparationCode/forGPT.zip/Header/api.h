#ifndef _api_H_
#define _api_H_

#include  "../header/halGPIO.h"     // private library - HAL layer

extern void DispFreqFromInput(void);
extern void PrepareLCDState1(void);
extern void CountSec(void);

float CalcFreq(int,int);
void NumToString(char*,int,int);
void SetTimeStrTo0(char*);
void WaitOneSec(void);
void UpdateTime(char*);

#endif







