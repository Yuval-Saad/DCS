File Name                                         Description
----------------------------------------------------------------------------------------
msp430g2xx3_1.c                                   Software Toggle P1.0
msp430g2xx3_1_vlo.c                               Software Toggle P1.0, MCLK = VLO/8
msp430g2xx3_P1_01.c                               Software Poll P1.4, Set P1.0 if P1.4 = 1
msp430g2xx3_P1_02.c                               Software Port Interrupt Service on P1.4 from LPM4
msp430g2xx3_P1_03.c                               Poll P1 With Software with Internal Pull-up
msp430g2xx3_P1_04.c                               P1 Interrupt from LPM4 with Internal Pull-up